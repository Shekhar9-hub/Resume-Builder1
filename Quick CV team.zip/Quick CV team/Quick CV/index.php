<!DOCTYPE html>
<html lang="en">
<head>
 
  <title>Online Resume Buider</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
  <link href="https://fonts.googleapis.com/css?family=Montserrat" rel="stylesheet" type="text/css">
  <link href="https://fonts.googleapis.com/css?family=Lato" rel="stylesheet" type="text/css">
  <link rel="stylesheet" href="css/style.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
  
</head>
<body id="myPage" data-spy="scroll" data-target=".navbar" data-offset="60">

<nav class="navbar navbar-default navbar-fixed-top">
  <div class="container">
    <div class="navbar-header">
      <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#myNavbar">
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>                        
      </button>
      <a class="navbar-brand" href="index.php">Quick CV</a>
    </div>
    <div class="collapse navbar-collapse" id="myNavbar">
      <ul class="nav navbar-nav navbar-right">
        <li><a href="index.php">ABOUT</a></li>
        <li><a href="services.php">SERVICES</a></li>
        <li><a href="signin.php">CREATE RESUME</a></li>
        <li><a href="adminlogin.php">ADMIN LOGIN</a></li>
        <li><a href="contact.php">CONTACT</a></li>
      </ul>
    </div>
  </div>
</nav>

<div class="jumbotron text-center hero">
  <h1>Resume Templates for
Every Job</h1> 
  <p>Whether you’re looking for something creative and fun or elegant and
powerful, we’ve got resume templates that can help you win the job.
Once you’ve found your favorite design, use our super simple resume
builder to make a standout application quickly and easily.</p> 
  <form>
</div>

<!-- Container (About Section) -->
<div id="about" class="container-fluid">
  <div class="row">
    <div class="col-sm-6">
      <h2>About US</h2><br>
      <h4 class='text-justify'>Picking the perfect format for your needs is one of the most important choices you’ll make on your resume. For many recruiters, the wrong format may be a huge pet peeve and get you rejected almost immediately. But don’t worry, below, we break down everything you need to consider to make the right choice.</h4><br>
      <p>

</p>
    </div>
    <div class="col-sm-6 text-center">
      <img src='img/image_4.jpg' class='img-fluid shadow' style='height:400px;object-fit:cover;'>
    </div>
  </div>
</div>

<div class="container-fluid bg-grey">
  <div class="row">
    <div class="col-sm-6">
    <img src='img/image_2.jpg' class='img-fluid' style='height:400px;object-fit:cover;padding-top:100px'>
     
    
    </div>
    <div class="col-sm-6">
      <h2>Our Values</h2><br>
      <h4><strong>MISSION:</strong> Our institution teach students how to come up with winning professional resumes and overlook the importance of student- and entry-level resumes. Yet, the latter are important in ensuring the student enters the job market to gain relevant experience that will then feature in the professional resume.

This becomes a problem for students intending to create a resume. </h4><br>
      <p><strong>VISION:</strong> Given this challenge, it is important for any resume templates intended for students to highlight the section about education more prominently. Emphasizing on awards/honors, GPA scores and exemplary performances in extracurricular activities is important. As is the case with entry-level resumes, including volunteer work experience and internships is also a good idea for student resumes.</p></div>
  </div>
</div>

<!-- Container (Portfolio Section) -->
<div id="portfolio" class="container-fluid text-center bg-grey">
  <h2>Portfolio</h2><br>
  <h4>What we have created</h4>
  <div class="row text-center slideanim">
    <div class="col-sm-4">
      <div class="thumbnail">
        <img src="img/resume.jpeg"  width="400" height="300">
        <p><strong>Build Resume</strong></p>
        <p>Yes, we built this</p>
      </div>
    </div>
    <div class="col-sm-4">
      <div class="thumbnail">
        <img src="img/r.jpeg"  width="400" height="300">
        <p><strong>Build Resume</strong></p>
        <p>Yes, we built this</p>
      </div>
    </div>
    <div class="col-sm-4">
      <div class="thumbnail">
        <img src="img/resume.jpeg" width="400" height="300">
        <p><strong>Build Resume</strong></p>
        <p>Yes, we built this</p>
      </div>
    </div>
  </div><br>
  

<footer class="container-fluid text-center">
  <a href="#myPage" title="To Top">
    <span class="glyphicon glyphicon-chevron-up"></span>
  </a>
  <p> Developed by Us</p>
</footer>

<script>
$(document).ready(function(){
  // Add smooth scrolling to all links in navbar + footer link
  $(".navbar a, footer a[href='#myPage']").on('click', function(event) {
    // Make sure this.hash has a value before overriding default behavior
    if (this.hash !== "") {
      // Prevent default anchor click behavior
      event.preventDefault();

      // Store hash
      var hash = this.hash;

      // Using jQuery's animate() method to add smooth page scroll
      // The optional number (900) specifies the number of milliseconds it takes to scroll to the specified area
      $('html, body').animate({
        scrollTop: $(hash).offset().top
      }, 900, function(){
   
        // Add hash (#) to URL when done scrolling (default click behavior)
        window.location.hash = hash;
      });
    } // End if
  });
  
  $(window).scroll(function() {
    $(".slideanim").each(function(){
      var pos = $(this).offset().top;

      var winTop = $(window).scrollTop();
        if (pos < winTop + 600) {
          $(this).addClass("slide");
        }
    });
  });
})
</script>

</body>
</html>
