<?php
 $id = $_GET['eid'];
 include('dbconn.php');
 $sql = "select * from personal_details where id = $id";
 $result1 = $con->query($sql);
 $row = $result1->fetch_array();
 $sq = "select * from education_details where eid = $id";
 $result2 = $con->query($sq);
 $row2 = $result2->fetch_array();
 

?><!DOCTYPE html>
<html>
    <head>
        <title>Creative Resume</title>
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
        <link rel="stylesheet" href="css/bootstrap.min.css">
        <link rel="stylesheet" href="css/w3.css">
        <script src="js/bootstrap.min.js"></script>
<style>
       body{
           margin:30px;
           font-family: 'Lucida Sans', 'Lucida Sans Regular', 'Lucida Grande', 'Lucida Sans Unicode', Geneva, Verdana, sans-serif;
       }  

        </style>
    </head>
    <body> 
        <h1><?php echo $row['name']; ?></h1>
        <div class="container-fluid">
            <div class="row">
                <div class="col-sm-8">
                    <p>
                        <i class="fa fa-home w3-text-red"></i> <?php echo $row['address']; ?><br>
                        <span><i class="fa fa-envelope w3-text-red"></i>  <?php echo $row['email']; ?></span><br>
                        <span><i class="fa fa-phone w3-text-red"></i> <?php echo $row['phone']; ?> </span>
                    </p>
                </div>
                <div class="col-sm-4">
                   
                    <img src="a.jpg" alt="">
                </div>
            </div>
        </div>
        <div class="container-fluid">
            <div class="row">
                <div class="col-sm-12 text-justify">
                    <h1 class='bg-danger w3-text-white p-2'>PROFESSIONAL SUMMARY</h1>
                    <p class="pt-5">
                    <?php echo $row2['summary']; ?>   
                </p>
    </div>
    <div class="col-sm-12">
                <h1 class='bg-danger w3-text-white p-2'>SKILLS</h1>
                 <br>
                 <br>
                 <b><?php echo $row2['skill']; ?><b>
                 <div class="progress">
                     <div class="progress-bar bg-danger" style='width:50%'>
                     <b><?php echo $row2['level']; ?><b> 50%
                     </div>
                 </div>
                 <br>
                <br>
                <b><?php echo $row2['skill2']; ?><b>
                 <div class="progress">
                    <div class="progress-bar bg-danger" style='width:50%'>
                    <b><?php echo $row2['level2']; ?><b> 50%
                    </div>
                </div>
                <br>
                <br>
                <b><?php echo $row2['skill3']; ?><b>
                <div class="progress">
                    <div class="progress-bar bg-danger" style='width:75%'>
                    <b><?php echo $row2['level3']; ?><b> 75%
                    </div>
                </div>
                <br>
                <br>

                
                </div>
               
            </div>
        </div>
        
        <div class="container-fluid">
            <div class="row">
                <div class="col-sm-12 text-justify">
                <h1 class='bg-danger w3-text-white p-2'>EMPLOYMENT HISTORY</h1>
                    <p class="pt-5">
                   
                    <h2><?php echo $row['job']; ?></h2><br>
                    <span class="w3-text-red">
                    <b>Starting Date</b> <?php echo $row['sdate']; ?>
                   <br>
                   <b> Ending Date </b> <?php echo $row['edate']; ?>
                    </span><br>
                    
                   <span><?php echo $row['desp']; ?></span>
                   <br>
                    <br>
                </div>
                <div class="col-sm-12">
                <h1 class='bg-danger w3-text-white p-2'>HOBBIES</h1>
                 <br>
                 <br>
                 <?php echo $row2['h1']; ?><br><br>
                 <?php echo $row2['h2']; ?><br><br>
                 
                </div>
                </div>
        </div>

        
        <div class="container-fluid">
            <div class="row">
                <div class="col-sm-12 text-justify">
                  
                <h1 class='bg-danger w3-text-white p-2'>EDUCATION</h1>
                    <p class="pt-5">
                    <b>Graduation Year</b>
                    <br>
                    
                    <span class="w3-text-red"><?php echo $row2['grad']; ?></span><br>
                    <b class='w3-large'>College Name</b><br>
                                <span class="font-weight-bold"> <?php echo $row2['college']; ?></span><br>
                                <span class="small"><b>Course: </b> <?php echo $row2['deg']; ?></span><br>
                                <span class="small"><b>Marks: </b> <?php echo $row2['gmark']; ?></span><br>
                                <span class="small"><b>City: </b> <?php echo $row2['city']; ?></span><br>
                                <span class="small"><b>State: </b> <?php echo $row2['state']; ?></span>
                                
                   <br>
                   <br>
                   <?php
                            if(($row2['pname']=="NA" || $row2['pdeg']=="NA" || $row2['pdate']=="NA") && ($row2['oname']=="NA" || 
                            $row2['odeg']=="NA" || $row2['odate']=="NA"))
                            {
                             echo "";
                            }
                            else if(($row2['oname']=="NA" || 
                            $row2['odeg']=="NA" || $row2['odate']=="NA"))
                            {
                                ?>

                            <b class='w3-large'>College or University Name</b><br>
                                <span class="font-weight-bold"> <?php echo $row2['pname']; ?></span><br>
                                <span class="small"><b>Programme Name: </b> <?php echo $row2['pdeg']; ?></span><br>
                                <span class="small"><b>Year of Studies: </b> <?php echo $row2['pdate']; ?></span><br>
                                <span class="small"><b>Marks: </b> <?php echo $row2['pmark']; ?></span><br>
                              
                                
                                
                                
                             
                                <br>
                                <br>    
                           
                                <?php
                            }
                            else{
                               ?>
                              
                            <b class='w3-large'>College or University Name</b><br>
                                <span class="font-weight-bold"> <?php echo $row2['pname']; ?></span><br>
                                <span class="small"><b>Programme Name: </b> <?php echo $row2['pdeg']; ?></span><br>
                                <span class="small"><b>Year of Studies: </b> <?php echo $row2['pdate']; ?></span><br>
                                <span class="small"><b>Marks: </b> <?php echo $row2['pmark']; ?></span><br>
                              
                                
                                
                                
                        
                                <br>
                                <br>
                           
                            <b class='w3-large'>College or University Name</b><br>
                                <span class="font-weight-bold"> <?php echo $row2['oname']; ?></span><br>
                                <span class="small"><b>Programme Name: </b> <?php echo $row2['odeg']; ?></span><br>
                                <span class="small"><b>Year of Studies: </b> <?php echo $row2['odate']; ?></span><br>
                                <span class="small"><b>Marks: </b> <?php echo $row2['omark']; ?></span><br>
                              
                                
                                
                                
                                <br>
                                <br>
                               <?php
                            }

                            ?>
                            
                   <b class='w3-large'>School Name</b><br>
                                <span class="font-weight-bold"> <?php echo $row2['school']; ?></span><br>
                                <span class="small"><b>Year of Higher Studies: </b> <?php echo $row2['high']; ?></span><br>
                                <span class="small"><b>Marks: </b> <?php echo $row2['marks']; ?></span><br>
                                <span class="small"><b>City: </b> <?php echo $row2['sc']; ?></span><br>
                                <span class="small"><b>State: </b> <?php echo $row2['ss']; ?></span>
                    </p>
                </div>
                <div class="col-sm-12">
                <h1 class='bg-danger w3-text-white p-2'>LANGUAGES</h1>
                 <br>
                 <br>
                 ENGLISH
                 <div class="progress">
                    <div class="progress-bar bg-danger" style='width:60%'>
                       60%
                    </div>
                </div>
                <br>
               <br>
               PUNJABI
                <div class="progress">
                   <div class="progress-bar bg-danger" style='width:50%'>
                      50%
                   </div>
               </div>
               <br>
               <br>
               HINDI
               <div class="progress">
                   <div class="progress-bar bg-danger" style='width:40%'>
                      40%
                   </div>
               </div>
               <br>
               <br>

                </div>
                </div>
        </div>
        <div class="container-fluid">
            <div class="row">
                <div class="col-sm-12">
                <h1 class='bg-danger w3-text-white p-2'>HONORS</h1>
                    <p class="mt-5">
                      
                        <b>Board Member mensa, NY</b><br>
                      <span class="w3-text-red"><?php echo date('d/m/Y') ?></span>
                    </p>
                </div>
            </div>
        </div>
        <a href='generatepdf2.php?id=<?php echo $id ?>' class='btn btn-warning'>Generate PDF</a>
        <a href='editdetails.php?id=<?php echo $id ?>' class='btn btn-primary float-right'>Edit Details</a>
    </body>
    </html>