<!DOCTYPE html>
<html lang="en">
<head>
 
  <title>Online Resume Buider</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
  <link href="https://fonts.googleapis.com/css?family=Montserrat" rel="stylesheet" type="text/css">
  <link href="https://fonts.googleapis.com/css?family=Lato" rel="stylesheet" type="text/css">
  <link rel="stylesheet" href="css/w3.css">
  <link rel="stylesheet" href="css/style.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
  
</head>
<body id="myPage" data-spy="scroll" data-target=".navbar" data-offset="60">

<nav class="navbar navbar-default navbar-fixed-top">
  <div class="container">
    <div class="navbar-header">
      <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#myNavbar">
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>                        
      </button>
      <a class="navbar-brand" href="index.php">Quick CV Admin Dashboard</a>
    </div>
    <div class="collapse navbar-collapse" id="myNavbar">
      <ul class="nav navbar-nav navbar-right">
       
        <li><a href="welcomeadmin.php">SEE RESUME</a></li>
        
        <li><a href="welcomeadmin.php" style='text-transform:uppercase'>Hello Admin</a></li>
        <li><a href="adminlogout.php">LOGOUT</a></li>
        
      </ul>
    </div>
  </div>
</nav>
<!-- Sidebar -->
<div class="w3-sidebar w3-light-grey w3-bar-block w3-pale-blue" style="width:25%">
  <h3 class="w3-bar-item">Menu</h3>
  <a href="addresume.php" class="w3-bar-item w3-button">Add Resume Templates</a>
  <a href="viewstudents.php" class="w3-bar-item w3-button">View Students</a>
  <a href="queries.php" class="w3-bar-item w3-button">View Queries</a>
  <a href="downloadresumes.php" class="w3-bar-item w3-button">Download Individual Resume</a>
  <a href="otherss.php" class="w3-bar-item w3-button">Download Multiple Resumes</a>
  
  
  <a href="adminpassword.php" class="w3-bar-item w3-button">Change Passwords</a>
</div>