<?php
session_start();
if(!isset($_SESSION['admin']))
{
    echo "<a href='signin.php'>Login Again</a><br><p>This session is expired</p>";

}
else
{
    //echo $_SESSION['user'];
    include('adminnav.php');
    ?>
<div class="container-fluid" style='width:50%;padding-top:100px'>
  <div class="row">
    <div class="col-sm-4">
    <!-- <img src='img/image_2.jpg' class='img-fluid' style='height:400px;object-fit:cover;padding-top:100px'>
     
     -->
    </div>
    <div class="col-sm-8 text-center">
        <h1 class='text-center'>
            Add Resume</h1>
            <br>
     <form method='post' enctype='multipart/form-data'>
<div class='form-group'>
<select class='form-control' required name='type'>
<option value="">Please Select Type of Resume</option>
<option value="Professional">Professional Resume</option>
<option value="Creative">Creative Resume </option>
<option value="Simple">Simple Resume</option>

</select>
</div>
<div class='form-group'>
<input type='file' name='file' class='form-control' required>
</div>
<input type='submit' class='btn btn-warning' name='add'>
</form>
    
  </div>
  
</div

<?php
if(isset($_POST['add']))
{
    $n = $_POST['type'];
    $h = $_FILES['file']['name'];
  date_default_timezone_set("Asia/Kolkata");
  $d = date("d/m/Y",time());
if(move_uploaded_file($_FILES['file']['tmp_name'],$h))
{
    
    include("dbconn.php");
    $query = "select * from add_resume where type = '$n'";
    $result = $con->query($query);
    list($a1,$b1,$c1,$d1)=$result->fetch_array();
    if($n == $b1)
    {
        echo "<script>alert('Resume already exists');</script>";
    }
    else{
    $q = "insert into add_resume(type,dtime,rname) values ('$n','$d','$h')";
    if($con->query($q))
	{
        echo "<script>alert('Resume is added');
        location.replace('addresume.php');</script>";
	}
	
	
	else
	{
        echo "<script>alert('Please try again Later');
        location.replace('addresume.php');
        </script>";
	}
	

}
}

else{
   echo "<center><h1>Not Uploaded</h1></center>";
}
}
?>

<?php
}
?>