<style>
#p1,#p2{
  display:none;
  outline:0px;
}
</style>
<?php
session_start();
if(!isset($_SESSION['user']))
{
    echo "<a href='signin.php'>Login Again</a><br><p>This session is expired</p>";

}
else
{
    //echo $_SESSION['user'];
    include('usernav.php');
}




?>
<div id="about" class="container-fluid">
  <div class="row" style="padding-top:50px">
  
    <div class="col-sm-6">
    <h1>Education Section</h1>
   <form method="post">
    <div class='form-group'>
    <input type='text' placeholder='Enter your College or University Name' class='form-control'  name="cname"  required>
    </div>
    <div class='form-group'>
    <input type='text' placeholder='Enter your City' class='form-control'  name="c" required>
    </div>
    <div class='form-group'>
    <input type='text' placeholder='Enter your State' class='form-control'  name="state" required>
    </div>
    <div class='form-group'>
    <input type='text' placeholder='Enter your Degree' class='form-control'  name="deg" required>
    </div>
    <div class='form-group'>
    Graduation Date

    <input type='month' class='form-control'  name="grad" required>
    </div>
    <div class='form-group'>
    <input type='number' placeholder='Enter your Marks in graduation'  name="gmark" class='form-control' required min="20" max="100">
    </div>
    
    <div class='form-group'>
    <input type='text' placeholder='Enter your School'  name="school" class='form-control' required>
    </div>
    <div class='form-group'>
    <input type='text' placeholder='Enter your City'  name="cs" class='form-control' required>
    </div>
    <div class='form-group'>
    <input type='text' placeholder='Enter your State' name="ss"  class='form-control' required>
    </div>
    <div class='form-group'>
    <input type='number' placeholder='Enter your Marks in +2'  name="high" class='form-control' required min="20" max="100">
    
    </div>
    <div class='form-group'>
    Higher Secondary
    
    <input type='month' class='form-control' name="sm"  required>
    </div>

    <center><button class="btn btn-warning" id="b1" type="button" title="Add Post Graduation Details"><i class="fa fa-plus-square"></i>
    &nbsp;&nbsp;&nbsp;  Add Post Graduation Details</button></center>
<br>
<div id="p1">
   <div class='form-group'>
    <input type='text' placeholder='Enter your College or University Name' class='form-control'  name="pname">
    </div>
    <div class='form-group'>
    <input type='text' placeholder='Enter your Post Graduation' class='form-control'  name="pdeg">
    </div>
    <div class='form-group'>
    Post Graduation Date
    <input type='month' class='form-control'  name="pgrad">
    </div>
    <div class='form-group'>
    <input type='number' placeholder='Enter your Marks in post graduation'  name="pgmark" class='form-control' min="20" max="100">
    </div>
    <center><button class="btn btn-warning" id="b2" type="button" title="Add more Education Details"><i class="fa fa-plus-square"></i>
    &nbsp;&nbsp;&nbsp;  Add More Education Details</button></center>
    <br>
    <div id="p2">
    <div class='form-group'>
    <input type='text' placeholder='Enter your College or University Name for Other Diploma or Education' class='form-control'  name="oname">
    </div>
    <div class='form-group'>
    <input type='text' placeholder='Enter Course Name' class='form-control'  name="odeg">
    </div>
    <div class='form-group'>
   Full Completion Date
    <input type='month' class='form-control'  name="ograd">
    </div>
    <div class='form-group'>
    <input type='number' placeholder='Enter your Marks in course'  name="ogmark" class='form-control' min="20" max="100">
    </div>

    </div>
     </div>


    </div>
    <div class="col-sm-6">
   <h1>Hobby</h1>
   <div class='form-group'>
    <input type='text' placeholder='Mention Your Hobby' class='form-control' name='h1' required>
    </div>
    <div class='form-group'>
    <input type='text' placeholder='Mention Your Hobby' class='form-control' name='h2' required>
    </div>
    
    <h1>Skills</h1>
  
    <div class='form-group'>
    <input type='text' placeholder='Enter your Skill' class='form-control' name='s1' required>
    </div>
    <div class='form-group'>
    <select name='skill1' class='form-control' required>
    <option value=''>Please Select</option>
    <option value='Novice'>Novice</option>
    <option value='Beginner'>Beginner</option>
    <option value='Experienced'>Experienced</option>
    
    
    
    </select>
        </div>
        <div class='form-group'>
    <input type='text' placeholder='Enter your Skill' class='form-control' name='s2' required>
    </div>
    <div class='form-group'>
    <select name='skill2' class='form-control' required>
    <option value=''>Please Select</option>
    <option value='Novice'>Novice</option>
    <option value='Beginner'>Beginner</option>
    <option value='Experienced'>Experienced</option>
    
    
    
    </select>
        </div><div class='form-group'>
    <input type='text' placeholder='Enter your Skill' class='form-control' name='s3' required>
    </div>
    <div class='form-group'>
    <select name='skill3' class='form-control' required>
    <option value=''>Please Select</option>
    <option value='Novice'>Novice</option>
    <option value='Beginner'>Beginner</option>
    <option value='Experienced'>Experienced</option>
    
    
    
    </select>
        </div>

        <div class='form-group'>
    <textarea class='form-control' placeholder='Professional Summary' name='summary' required></textarea>
    </div>
    
    <br><input type='submit' class="btn btn-primary btn-lg pull-right" name='save1' value='Save and Next'></a>
    </form>
    
    </div>
    
  </div>
  <a href='build_resume.php' class='btn btn-danger'>Back</a>
  </div>
  <script src="js/script.js"></script>
<script>
$(document).ready(function(){
  $("#b1").click(function(){
    $("#p1").toggle();
  });
  $("#b2").click(function(){
    $("#p2").toggle();
  });
  
});
</script>

  <?php

//echo "<center><a href='view.php?id=".$id."' class='btn btn-danger'>Go and Download Resume</a></center>";
if(isset($_POST['save1']))
{
    

  //Education Details...



$a2=$_POST['cname'];
$b2=$_POST['c'];
$c2=$_POST['state'];
$d2=$_POST['deg'];
$e2=$_POST['grad'];
$f2=$_POST['gmark'];
$g2=$_POST['school'];
$a3=$_POST['cs'];
$b3=$_POST['ss'];
$c3=$_POST['high'];
$d3=$_POST['sm'];
$e4=$_POST['s1'];
$e5=$_POST['skill1'];
$e6=$_POST['s2'];
$e7=$_POST['skill2'];
$e8=$_POST['s3'];
$e9=$_POST['skill3'];
$e10=$_POST['summary'];
$p1=$_POST['pname'];
$p2=$_POST['pdeg'];
$p3=$_POST['pgrad'];
$p4=$_POST['pgmark'];
$o1=$_POST['oname'];
$o2=$_POST['odeg'];
$o3=$_POST['ograd'];
$o4=$_POST['ogmark'];
$h1=$_POST['h1'];
$h2=$_POST['h2'];
// $u = $_SESSION['user'];
// $id = $_GET['id'];
include('dbconn.php');
 

 
 $query = "select * from personal_details where email = '".$_SESSION['email']."'";
    $result = $con->query($query);
    $row = $result->fetch_array();
 $fk = $row['id'];
 $q = "select * from education_details where eid = $fk";
 $r = $con->query($q);
 $rr=$r->fetch_array();
 if($rr['eid'] == $fk)
 {
     echo "<script>alert('This student already exists');</script>";
 }
 else
 {
   if((empty($p1)||empty($p2)||empty($p3)||empty($p4)) && (empty($o1)||empty($o2)||empty($o3)||empty($o4)))
   {
    $q1 = "INSERT into `education_details` 
    VALUES ('$fk','$a2','$b2','$c2','$d2','$e2','$f2','$g2','$a3','$b3','$c3','$d3','$e4','$e5','$e6','$e7','$e8','$e9','$e10','NA','NA','NA','NA','NA','NA','NA','NA','$h1','$h2')";
   
   }
   else if(empty($o1)||empty($o2)||empty($o3)||empty($o4))
   {
    $q1 = "INSERT into `education_details` 
    VALUES ('$fk','$a2','$b2','$c2','$d2','$e2','$f2','$g2','$a3','$b3','$c3','$d3','$e4','$e5','$e6','$e7','$e8','$e9','$e10','$p1','$p2','$p3','$p4','NA','NA','NA','NA','$h1','$h2')";
   
   }
   else
   {
 $q1 = "INSERT into `education_details` 
 VALUES ('$fk','$a2','$b2','$c2','$d2','$e2','$f2','$g2','$a3','$b3','$c3','$d3','$e4','$e5','$e6','$e7','$e8','$e9','$e10','$p1','$p2','$p3','$p4','$o1','$o2','$o3','$o4','$h1','$h2')";
   }
 if($con->query($q1))
 {
 echo "<script> location.replace('build.php?eid=".$fk."&tmp_id=".$row['temp_id']."'); </script>";  
 }
 else{
    echo "<script>alert('Try Again!! Error Occur');location.replace('build_resume.php');</script>";
 }
 //echo "<center><a href='view.php?id='".$id."' class='btn btn-danger'>Go and Download Resume</a></center>";
}
//echo "<script> location.replace('build.php?eid=".$fk."&tmp_id=".$rr['temp_id']."'); </script>";
//echo "<script> location.replace('build.php?eid=".$fk."&tmp_id=".$row['temp_id']."'); </script>";  
}

?>
 
