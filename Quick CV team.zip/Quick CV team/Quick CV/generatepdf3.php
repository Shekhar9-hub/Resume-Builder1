<?php
session_start();
$id = $_GET['id'];
include('dbconn.php');
$sql = "select * from personal_details where id = $id";
$result1 = $con->query($sql);
$row = $result1->fetch_array();
$sq = "select * from education_details where eid = $id";
$result2 = $con->query($sq);
$row2 = $result2->fetch_array();
$name = $row['name'];
$course = $row2['deg'];
$resume = "Simple Resume ".$id.".pdf";
$q = "insert into student_resume(sid,name,course,resume) values($id,'$name','$course','$resume')";
$con->query($q);  

if(($row2['pname']=="NA" || $row2['pdeg']=="NA" || $row2['pdate']=="NA") && ($row2['oname']=="NA" || 
                            $row2['odeg']=="NA" || $row2['odate']=="NA"))
                            {
$html = '<!DOCTYPE html>
<html>
<head>

<title>'.$row['name'].' | '.$row['email'].'</title>
<meta http-equiv="content-type" content="text/html; charset=utf-8" />

<meta name="keywords" content="" />
<meta name="description" content="" />
	<link rel="stylesheet" type="text/css" href="http://yui.yahooapis.com/2.7.0/build/reset-fonts-grids/reset-fonts-grids.css" media="all" /> 

<style>
body{
    font-family: Georgia;
}
.grey{
    width:100%;
    background-color:#f1f1f1;
    border-top:8px solid darkslategrey;
   padding:20px;
   padding-bottom:120px;

    
    
}
.heading{
    font-size:40px;
    text-transform:uppercase;
     
}
.italic{
    font-size:25px;
    color:darkslategrey;
    letter-spacing:1px;
}
.red{
    font-size:18px;
    float:right;
    text-transform:lowercase;
    color:crimson;
}
.black{
    font-size:18px;
    float:right;
    text-transform:lowercase;
    color:darkslategrey;
}
.light{
    color:lightgrey;
}
.align{
    float:none;
    text-transform:capitalize;
}
.small{
    font-size:15px;
    text-transform:capitalize;
}

</style>
</head>
<body>
<div class="grey">
<h1 class="heading">'.$row['name'].'<span class="red"><u>'.$row['email'].'</u></span>
<br>
<i class="italic">'.$row['job'].'</i><span class="black">'.$row['phone'].'</span>

</h1>
<br>
<hr class="light">
<p>
<i class="italic" style="text-transform:capitalize">Profile</i>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 
<span class="black align">'.$row2['summary'].'</span></p>

<hr class="light">

<p style="padding-bottom:10px"><i class="italic" style="text-transform:capitalize">Skills</i>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 
<span class="black align">'.$row2['skill'].'</span>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
&nbsp;&nbsp;
<span class="black align">'.$row2['skill2'].'</span><span class="black">'.$row2['skill3'].'</span>
<br>
<i class="italic" style="text-transform:capitalize;letter-spacing:0px">(Technical)</i>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 
<span class="black align small">'.$row2['level'].'</span>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
&nbsp;&nbsp;
<span class="black align small">'.$row2['level2'].'</span><span class="black small">'.$row2['level3'].'</span>
<br>
</p>
<hr class="light">
<p style="padding-bottom:10px"><i class="italic" style="text-transform:capitalize">Experience</i>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 
<span class="black align" style="text-transform:capitalize;">'.$row['job'].'
<br>
<i class="italic" style="text-transform:capitalize;letter-spacing:0px">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</i>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 
<span class="black align small">'.$row['sdate'].' to '.$row['edate'].'</span>
</span>
<br>
<i class="italic" style="text-transform:capitalize;letter-spacing:0px">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</i>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
&nbsp;<span class="black align small">'.$row['desp'].'</span>
</span>
<br>
</p>
<hr class="light">
<p style="padding-bottom:10px"><i class="italic" style="text-transform:capitalize">Education</i>&nbsp;&nbsp;&nbsp;&nbsp;
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
<span class="black align" style="text-transform:capitalize;">Graduation '.$row2['grad'].'
<br>
<i class="italic" style="text-transform:capitalize;letter-spacing:0px">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</i>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
<span class="black align small">'.$row2['college'].'</span>
</span>
<br>
<i class="italic" style="text-transform:capitalize;letter-spacing:0px">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</i>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
&nbsp;<span class="black align small">'.$row2['deg'].' - '.$row2['gmark'].'</span>
</span>
<br>
<i class="italic" style="text-transform:capitalize;letter-spacing:0px">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</i>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
<span class="black align" style="text-transform:capitalize;">Higher Studies '.$row2['high'].'
</span>
<br>
<i class="italic" style="text-transform:capitalize;letter-spacing:0px">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</i>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
<span class="black align small">'.$row2['school'].'</span>
</span>
<br>
<i class="italic" style="text-transform:capitalize;letter-spacing:0px">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</i>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
<span class="black align small"> 12th Marks- '.$row2['marks'].'</span>
</span>
</p>
<hr class="light">
<center><h4> '.$row['name'].' - <u style="color:crimson;">'.$row['email'].'</u> - '. $row['phone'].'</h4></center>
</div>



</html>';
}
else if(($row2['oname']=="NA" || 
$row2['odeg']=="NA" || $row2['odate']=="NA"))
{
    $html = '<!DOCTYPE html>
    <html>
    <head>
    
    <title>'.$row['name'].' | '.$row['email'].'</title>
    <meta http-equiv="content-type" content="text/html; charset=utf-8" />
    
    <meta name="keywords" content="" />
    <meta name="description" content="" />
        <link rel="stylesheet" type="text/css" href="http://yui.yahooapis.com/2.7.0/build/reset-fonts-grids/reset-fonts-grids.css" media="all" /> 
    
    <style>
    body{
        font-family: Georgia;
    }
    .grey{
        width:100%;
        background-color:#f1f1f1;
        border-top:8px solid darkslategrey;
       padding:20px;
       padding-bottom:120px;
    
        
        
    }
    .heading{
        font-size:40px;
        text-transform:uppercase;
         
    }
    .italic{
        font-size:25px;
        color:darkslategrey;
        letter-spacing:1px;
    }
    .red{
        font-size:18px;
        float:right;
        text-transform:lowercase;
        color:crimson;
    }
    .black{
        font-size:18px;
        float:right;
        text-transform:lowercase;
        color:darkslategrey;
    }
    .light{
        color:lightgrey;
    }
    .align{
        float:none;
        text-transform:capitalize;
    }
    .small{
        font-size:15px;
        text-transform:capitalize;
    }
    
    </style>
    </head>
    <body>
    <div class="grey">
    <h1 class="heading">'.$row['name'].'<span class="red"><u>'.$row['email'].'</u></span>
    <br>
    <i class="italic">'.$row['job'].'</i><span class="black">'.$row['phone'].'</span>
    
    </h1>
    <br>
    <hr class="light">
    <p>
    <i class="italic" style="text-transform:capitalize">Profile</i>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 
    <span class="black align">'.$row2['summary'].'</span></p>
    
    <hr class="light">
    
    <p style="padding-bottom:10px"><i class="italic" style="text-transform:capitalize">Skills</i>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
    &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 
    <span class="black align">'.$row2['skill'].'</span>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
    &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
    &nbsp;&nbsp;
    <span class="black align">'.$row2['skill2'].'</span><span class="black">'.$row2['skill3'].'</span>
    <br>
    <i class="italic" style="text-transform:capitalize;letter-spacing:0px">(Technical)</i>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 
    <span class="black align small">'.$row2['level'].'</span>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
    &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
    &nbsp;&nbsp;
    <span class="black align small">'.$row2['level2'].'</span><span class="black small">'.$row2['level3'].'</span>
    <br>
    </p>
    <hr class="light">
    <p style="padding-bottom:10px"><i class="italic" style="text-transform:capitalize">Experience</i>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 
    <span class="black align" style="text-transform:capitalize;">'.$row['job'].'
    <br>
    <i class="italic" style="text-transform:capitalize;letter-spacing:0px">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
    &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</i>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 
    <span class="black align small">'.$row['sdate'].' to '.$row['edate'].'</span>
    </span>
    <br>
    <i class="italic" style="text-transform:capitalize;letter-spacing:0px">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
    &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</i>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
    &nbsp;<span class="black align small">'.$row['desp'].'</span>
    </span>
    <br>
    </p>
    <hr class="light">
    <p style="padding-bottom:10px"><i class="italic" style="text-transform:capitalize">Education</i>&nbsp;&nbsp;&nbsp;&nbsp;
    &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
    <span class="black align" style="text-transform:capitalize;">Graduation '.$row2['grad'].'
    <br>
    <i class="italic" style="text-transform:capitalize;letter-spacing:0px">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
    &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</i>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
    <span class="black align small">'.$row2['college'].'</span>
    </span>
    <br>
    <i class="italic" style="text-transform:capitalize;letter-spacing:0px">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
    &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</i>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
    &nbsp;<span class="black align small">'.$row2['deg'].' - '.$row2['gmark'].'</span>
    </span>
    <br>
    <p style="padding-bottom:10px">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
    &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
    &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
    <span class="black align" style="text-transform:capitalize;">Post Graduation '.$row2['pdate'].'
    <br>
    <i class="italic" style="text-transform:capitalize;letter-spacing:0px">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
    &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</i>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
    <span class="black align small">'.$row2['pname'].'</span>
    </span>
    <br>
    <i class="italic" style="text-transform:capitalize;letter-spacing:0px">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
    &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</i>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
    &nbsp;<span class="black align small">'.$row2['pdeg'].' - '.$row2['pmark'].'</span>
    </span>
    
    <br>
    <i class="italic" style="text-transform:capitalize;letter-spacing:0px">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
    &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</i>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
    <span class="black align" style="text-transform:capitalize;">Higher Studies '.$row2['high'].'
    </span>
    
    <br>
    <i class="italic" style="text-transform:capitalize;letter-spacing:0px">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
    &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</i>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
    <span class="black align small">'.$row2['school'].'</span>
    </span>
    <br>
    <i class="italic" style="text-transform:capitalize;letter-spacing:0px">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
    &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</i>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
    <span class="black align small"> 12th Marks- '.$row2['marks'].'</span>
    </span>
    </p>
    <hr class="light">
    <center><h4> '.$row['name'].' - <u style="color:crimson;">'.$row['email'].'</u> - '. $row['phone'].'</h4></center>
    </div>
    
    
    
    </html>';
}
else
{
    $html = '<!DOCTYPE html>
    <html>
    <head>
    
    <title>'.$row['name'].' | '.$row['email'].'</title>
    <meta http-equiv="content-type" content="text/html; charset=utf-8" />
    
    <meta name="keywords" content="" />
    <meta name="description" content="" />
        <link rel="stylesheet" type="text/css" href="http://yui.yahooapis.com/2.7.0/build/reset-fonts-grids/reset-fonts-grids.css" media="all" /> 
    
    <style>
    body{
        font-family: Georgia;
    }
    .grey{
        width:100%;
        background-color:#f1f1f1;
        border-top:8px solid darkslategrey;
       padding:20px;
       padding-bottom:120px;
    
        
        
    }
    .heading{
        font-size:40px;
        text-transform:uppercase;
         
    }
    .italic{
        font-size:25px;
        color:darkslategrey;
        letter-spacing:1px;
    }
    .red{
        font-size:18px;
        float:right;
        text-transform:lowercase;
        color:crimson;
    }
    .black{
        font-size:18px;
        float:right;
        text-transform:lowercase;
        color:darkslategrey;
    }
    .light{
        color:lightgrey;
    }
    .align{
        float:none;
        text-transform:capitalize;
    }
    .small{
        font-size:15px;
        text-transform:capitalize;
    }
    
    </style>
    </head>
    <body>
    <div class="grey">
    <h1 class="heading">'.$row['name'].'<span class="red"><u>'.$row['email'].'</u></span>
    <br>
    <i class="italic">'.$row['job'].'</i><span class="black">'.$row['phone'].'</span>
    
    </h1>
    <br>
    <hr class="light">
    <p>
    <i class="italic" style="text-transform:capitalize">Profile</i>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 
    <span class="black align">'.$row2['summary'].'</span></p>
    
    <hr class="light">
    
    <p style="padding-bottom:10px"><i class="italic" style="text-transform:capitalize">Skills</i>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
    &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 
    <span class="black align">'.$row2['skill'].'</span>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
    &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
    &nbsp;&nbsp;
    <span class="black align">'.$row2['skill2'].'</span><span class="black">'.$row2['skill3'].'</span>
    <br>
    <i class="italic" style="text-transform:capitalize;letter-spacing:0px">(Technical)</i>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 
    <span class="black align small">'.$row2['level'].'</span>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
    &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
    &nbsp;&nbsp;
    <span class="black align small">'.$row2['level2'].'</span><span class="black small">'.$row2['level3'].'</span>
    <br>
    </p>
    <hr class="light">
    <p style="padding-bottom:10px"><i class="italic" style="text-transform:capitalize">Experience</i>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 
    <span class="black align" style="text-transform:capitalize;">'.$row['job'].'
    <br>
    <i class="italic" style="text-transform:capitalize;letter-spacing:0px">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
    &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</i>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 
    <span class="black align small">'.$row['sdate'].' to '.$row['edate'].'</span>
    </span>
    <br>
    <i class="italic" style="text-transform:capitalize;letter-spacing:0px">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
    &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</i>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
    &nbsp;<span class="black align small">'.$row['desp'].'</span>
    </span>
    <br>
    </p>
    <hr class="light">
    <p style="padding-bottom:10px"><i class="italic" style="text-transform:capitalize">Education</i>&nbsp;&nbsp;&nbsp;&nbsp;
    &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
    <span class="black align" style="text-transform:capitalize;">Graduation '.$row2['grad'].'
    <br>
    <i class="italic" style="text-transform:capitalize;letter-spacing:0px">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
    &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</i>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
    <span class="black align small">'.$row2['college'].'</span>
    </span>
    <br>
    <i class="italic" style="text-transform:capitalize;letter-spacing:0px">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
    &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</i>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
    &nbsp;<span class="black align small">'.$row2['deg'].' - '.$row2['gmark'].'</span>
    </span>
    <br>
    <p style="padding-bottom:10px">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
    &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
    &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
    <span class="black align" style="text-transform:capitalize;">Post Graduation '.$row2['pdate'].'
    <br>
    <i class="italic" style="text-transform:capitalize;letter-spacing:0px">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
    &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</i>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
    <span class="black align small">'.$row2['pname'].'</span>
    </span>
    <br>
    <i class="italic" style="text-transform:capitalize;letter-spacing:0px">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
    &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</i>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
    &nbsp;<span class="black align small">'.$row2['pdeg'].' - '.$row2['pmark'].'</span>
    </span>
    <br>
    <p style="padding-bottom:10px">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
    &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
    &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
    <span class="black align" style="text-transform:capitalize;">Other Education or Diploma '.$row2['odate'].'
    <br>
    <i class="italic" style="text-transform:capitalize;letter-spacing:0px">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
    &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</i>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
    <span class="black align small">'.$row2['oname'].'</span>
    </span>
    <br>
    <i class="italic" style="text-transform:capitalize;letter-spacing:0px">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
    &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</i>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
    &nbsp;<span class="black align small">'.$row2['odeg'].' - '.$row2['omark'].'</span>
    </span>
    <br>
    <i class="italic" style="text-transform:capitalize;letter-spacing:0px">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
    &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</i>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
    <span class="black align" style="text-transform:capitalize;">Higher Studies '.$row2['high'].'
    </span>
    
    <br>
    <i class="italic" style="text-transform:capitalize;letter-spacing:0px">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
    &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</i>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
    <span class="black align small">'.$row2['school'].'</span>
    </span>
    <br>
    <i class="italic" style="text-transform:capitalize;letter-spacing:0px">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
    &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</i>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
    <span class="black align small"> 12th Marks- '.$row2['marks'].'</span>
    </span>
    </p>
    <hr class="light">
    <center><h4> '.$row['name'].' - <u style="color:crimson;">'.$row['email'].'</u> - '. $row['phone'].'</h4></center>
    </div>
    
    
    
    </html>';

}
?>
<?php

// Include autoloader 
require_once 'dompdf/autoload.inc.php'; 
 
// Reference the Dompdf namespace 
use Dompdf\Dompdf; 
 
// Instantiate and use the dompdf class 
$dompdf = new Dompdf();


$dompdf->loadHtml($html);

 
// (Optional) Setup the paper size and orientation 
$dompdf->setPaper('A4', 'Portrait'); 
 
// Render the HTML as PDF 
$dompdf->render(); 
//$dompdf->set_base_path('../css/bootstrap.min.css');
// Output the generated PDF (1 = download and 0 = preview) 
if(isset($_SESSION['admin']))
{
$dompdf->stream("Simple Resume", array("Attachment" => 1));
}
else
{
    $dompdf->stream("Simple Resume", array("Attachment" => 0));
    $output = $dompdf->output();
    file_put_contents("student resume/Simple Resume ".$id.".pdf", $output);

}
?>
