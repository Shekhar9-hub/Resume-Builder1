<?php session_start(); ?>
<!DOCTYPE html>
<html lang="en">
<head>

  <title>Online Resume Builder</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
  <link href="https://fonts.googleapis.com/css?family=Montserrat" rel="stylesheet" type="text/css">
  <link href="https://fonts.googleapis.com/css?family=Lato" rel="stylesheet" type="text/css">
  
  <link rel="stylesheet" href="css/style.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
  
</head>
<body id="myPage" data-spy="scroll" data-target=".navbar" data-offset="60">

<nav class="navbar navbar-default navbar-fixed-top">
  <div class="container">
    <div class="navbar-header">
      <!-- <button type="bucon-bar"></span> -->
        <span class="itton" class="navbar-toggle" data-toggle="collapse" data-target="#myNavbar">
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>                        
      </button>
      <a class="navbar-brand" href="index.php">Quick CV</a>
    </div>
    <div class="collapse navbar-collapse" id="myNavbar">
      <ul class="nav navbar-nav navbar-right">
        <li><a href="index.php">ABOUT</a></li>
        <li><a href="services.php">SERVICES</a></li>
        <li><a href="signin.php">CREATE RESUME</a></li>
        <li><a href="adminlogin.php">ADMIN LOGIN</a></li>
        <li><a href="contact.php">CONTACT</a></li>
      </ul>
    </div>
  </div>
</nav>

<body>
<div class="container-fluid text-center  pt-5 mt-5">
  <h1 class='display-4'>Sign in</h1> 
  <p style='padding-bottom:20px'>Welcome to Admin Portal</p>
  <div class="container p-5 m-5" style='width:30%'>
    <form method='post'>
<div class='form-group'>
<input type='text' placeholder="Your Email Address" name='email' class='form-control' required>
</div>
<div class='form-group'>
<input type='password' placeholder="Set your Password" name='pass' class='form-control' maxlength="15" required>
</div>

<button type='submit' class='btn btn-warning' name='login'>LOG IN</button>


<br>
</form>
<!-- <form method='post'>
<button type='submit' class='btn btn-warning float-right' name='alogin'>CREATE LOGIN FOR ADMIN</button></form> -->

<!-- <p>Don't have an Account</p> <a href='sign_up.php'>Create One</a> -->

</div>
  <form>
</div>
<?php
if(isset($_POST['login']))
{
    $email = $_POST['email'];
    $pass = md5($_POST['pass']);
    include("dbconn.php");
    $query = "select * from admin where email = '$email' and password = '$pass'";
    $r = $con->query($query);
    list($a,$b,$c) = $r->fetch_array();
	if($email == $b && $pass == $c)
	{
      $_SESSION['admin'] = $b;
    header("location:welcomeadmin.php");
    
	}
	else
	{
        echo "<script>alert('Credentials are wrong. Please Type Correct Credentials');
        location.replace('adminlogin.php');</script>";
	}
  
  
}

// if(isset($_POST['alogin']))
// {

//     $email = 'admin34@gmail.com';
//     $pass = 'admin12';
//     $c = md5($pass);
//     include("dbconn.php");
//     $query = "insert into admin(email,password) values('$email','$c')";
//     $r = $con->query($query);
//     if(mysqli_num_rows($r)<=2)
//     {
//       echo "<script>alert('Account is created');
//       location.replace('adminlogin.php');</script>";
//     }
  

    
	
// 	else
// 	{
//         echo "<script>alert('Only two accounts are created');
//         location.replace('adminlogin.php');</script>";
// 	}
  
  
// }



?>
</body>
</html>