<?php
set_include_path('/usr/lib/pear/'); 
session_start();
if(!isset($_SESSION['user']))
{
    echo "<a href='signin.php'>Login Again</a><br><p>This session is expired</p>";

}
else
{
    //echo $_SESSION['user'];
    //include('usernav.php');
    echo "<navclass='navbar-nav w3-teal pl-4 pr-4 pt-2 pb-2 m-0 w3-text-white'>".$_SESSION['user']."
    <a href='logout.php' class='float-right'>Logout</a></nav><hr>";
    //$id = $_GET['eid'];
    $template = $_GET['tmp_id'];
    include("dbconn.php");
    if($template == 1)
    {
        include('professional.php');
    }
    else if($template == 2)
    {
        include('creative.php');
    }
    else
    {
        include('srt-resume.php');
    }
      }
    
    




?>