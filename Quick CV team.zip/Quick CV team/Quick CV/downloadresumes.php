<?php
session_start();
if(!isset($_SESSION['admin']))
{
    echo "<a href='signin.php'>Login Again</a><br><p>This session is expired</p>";

}
else
{
    //echo $_SESSION['user'];
    include('adminnav.php');
    ?>
<div class="container-fluid" style='width:100%;padding-top:100px'>
  <div class="row">
    <div class="col-sm-4">
    <!-- <img src='img/image_2.jpg' class='img-fluid' style='height:400px;object-fit:cover;padding-top:100px'>
     
     -->
    </div>
    <div class="col-sm-8 text-center">
        <h1 class='text-center'>Download Student Resumes
           </h1>
           <div class="container">
           <br>
   <div class="form-group" style='width:70%'>
    <div class="input-group">
     <span class="input-group-addon">Search</span>
     <input type="text" name="search_text" id="search_text" placeholder="Search by Student Name" class="form-control" />
    </div>
   </div>
   </div>
   <br />
   <div id="result"></div>
  </div>
 </body>
</html>
<script src="js/jquery.js"></script>
<script>
$(document).ready(function(){

 load_data();

 function load_data(query)
 {
  $.ajax({
   url:"fetch2.php",
   method:"POST",
   data:{query:query},
   success:function(data)
   {
    $('#result').html(data);
   }
  });
 }
 $('#search_text').keyup(function(){
  var search = $(this).val();
  if(search != '')
  {
   load_data(search);
  }
  else
  {
   load_data();
  }
 });
});
</script>
            <?php
}
?>