<?php
//fetch.php
$connect = mysqli_connect("localhost", "root", "", "resume");
$output = '';
if(isset($_POST["query"]))
{
 $search = mysqli_real_escape_string($connect, $_POST["query"]);
 $query = "
  SELECT * FROM education_details
  WHERE deg LIKE '%".$search."%'
  OR pdeg LIKE '%".$search."%'";
//   OR City LIKE '%".$search."%' 
//   OR PostalCode LIKE '%".$search."%' 
//   OR Country LIKE '%".$search."%'

$result = mysqli_query($connect, $query);
if(mysqli_num_rows($result) > 0)
{
  $cnt = 1;
 $output .= '
  <div class="table-responsive">
   <table class="table table-bordered">
    <tr>
     <th>ID</th>
     <th>Name</th>
     <th>City</th>
     <th>Programme</th>
    <th>Download Resume</th>
     
    </tr>
 ';

 while($row = mysqli_fetch_array($result))
 {
     $i = $row['eid'];
     $q2  = "select * from personal_details where id=$i";
     $result1 = mysqli_query($connect,$q2);
     $row2 = mysqli_fetch_array($result1);
  $output .= '
  <tr>

    <td>'.$cnt.'</td>
   
    <td>'.$row2["name"].'</td>
    <td>'.$row2["city"].'</td>
    <td>'.$row['deg'].'</td>
    <td><input type="checkbox" value="'.$row2['id'].'" name="download[]"> Download PDF</td>
    
  ';
//   if($row2["temp_id"]==1)
//   {
//       $output .='<td><input type="checkbox" value="'.$row2['id'].'" name="download[]"> Download PDf
//     <a href="generatepdf.php?id='.$row2['id'].'">Download Pdf</a>
//       </td>';
//   }
//   else if($row2["temp_id"]==2)
//   {
//     $output .='<td><a href="generatepdf2.php?id='.$row2['id'].'">Download Pdf</a></td>';
//   }
//   else{
//     $output .='<td><a href="generatepdf3.php?id='.$row2['id'].'">Download Pdf</a></td>';
//   }

  $output.='</tr>';
  $cnt++;
 }
echo '<form method="post"><tr><td colspan="5"><input type="submit" value="Download in Zip" class="btn btn-danger pull-right" name="downloadpdf"></td></tr></form>';

 echo $output;
 
 echo "hello";

 if(isset($_POST['downloadpdf']))
{
    // if(isset($_POST['download']))
    // {
    //     foreach ($_POST['download'] as $val) {
            echo "hello";
    //     }
    // }
}
}




else
{
 echo 'Data Not Found';
}
}

// else
// {
//  $query = "
//   select * from signup;
//  ";
// }
// // $result = mysqli_query($connect, $query);
// if(mysqli_num_rows($result) > 0)
// {
//   $cnt = 1;
//  $output .= '
//   <div class="table-responsive">
//    <table class="table table-bordered">
//     <tr>
//      <th>ID</th>
//      <th>Name</th>
//      <th>Email</th>
    
     
//     </tr>
//  ';
//  while($row = mysqli_fetch_array($result))
//  {
//   $output .= '
//    <tr>

//     <td>'.$cnt.'</td>
//     <td>'.$row["name"].'</td>
//     <td>'.$row["email"].'</td>
    
    
//    </tr>
//   ';
//   $cnt++;
//  }
//  echo $output;
// }
// else
// {
//  echo 'Data Not Found';
// }

?>
