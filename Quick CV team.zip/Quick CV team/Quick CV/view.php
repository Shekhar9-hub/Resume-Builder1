<?php
session_start();
if(!isset($_SESSION['user']))
{
    echo "<a href='signin.php'>Login Again</a><br><p>This session is expired</p>";

}
else
{

    $id = $_GET['id'];
    include("dbconn.php");
    $query = "select * from add_resume where id='$id'";
    $r = $con->query($query);
    if(list($a,$b,$c,$d) = $r->fetch_array())
    {
       echo "<center><h1 style='padding-top:10px;'>".$b."</h1></center>";
        file_get_contents("localhost/Online Resume Builder/".$d);
    }
    
}




?>
