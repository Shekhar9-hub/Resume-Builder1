<!DOCTYPE html>
<html lang="en">
<head>

  <title>Online Resume Buider</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
  <link href="https://fonts.googleapis.com/css?family=Montserrat" rel="stylesheet" type="text/css">
  <link href="https://fonts.googleapis.com/css?family=Lato" rel="stylesheet" type="text/css">
  
  <link rel="stylesheet" href="css/style.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
  
</head>
<body id="myPage" data-spy="scroll" data-target=".navbar" data-offset="60">

<nav class="navbar navbar-default navbar-fixed-top">
  <div class="container">
    <div class="navbar-header">
      <!-- <button type="bucon-bar"></span> -->
        <span class="itton" class="navbar-toggle" data-toggle="collapse" data-target="#myNavbar">
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>                        
      </button>
      <a class="navbar-brand" href="index.php">Quick CV</a>
    </div>
    <div class="collapse navbar-collapse" id="myNavbar">
      <ul class="nav navbar-nav navbar-right">
        <li><a href="index.php">ABOUT</a></li>
        <li><a href="services.php">SERVICES</a></li>
        <li><a href="signin.php">CREATE RESUME</a></li>
        <li><a href="adminlogin.php">ADMIN LOGIN</a></li>
        <li><a href="contact.php">CONTACT</a></li>
      </ul>
    </div>
  </div>
</nav>

<body>
<div class="container-fluid text-center  pt-5 mt-5">
  <h1>SIGN UP</h1> 
  <p style='padding-bottom:20px'>New here? No Worries, Create New Account</p>
  <div class="container p-5 m-5" style='width:30%'>
    <form method='post'>
    <div class='form-group'>
<input type='text' placeholder="Your Full Name" name='name' class='form-control' required>
</div>
<div class='form-group'>
<input type='email' placeholder="Your Email Address" name='email' class='form-control' required>
</div>
<div class='form-group'>
<input type='password' placeholder="Set your Password" name='pass' class='form-control' maxlength="6" required>
</div>
<p> I agree to the <a href='#'>terms and conditions</a></p>
<button type='submit' class='btn btn-warning btn-block' name='signup'>SIGN UP</button>
<br>
<p>Already have an account?</p> <a href='signin.php'>Sign in</a>
</form>
</div>
  <form>
</div>

</body>
</html>
<?php
if(isset($_POST['signup']))
{
    $n = $_POST['name'];
    $a = $_POST['email'];
    $b = md5($_POST['pass']);
   include("dbconn.php");
    $query = "select * from signup where email = '$a'";
    $result = $con->query($query);
    list($a1,$b1,$c1,$d1)=$result->fetch_array();
    if($a == $c1)
    {
        echo "<script>alert('Email Id already exists');</script>";
    }
    else{
    $q = "insert into signup(name,email,password) values ('$n','$a','$b')";
    if($con->query($q))
	{
        echo "<script>alert('Account is created');
        location.replace('signin.php');</script>";
	}
	
	
	else
	{
        echo "<script>alert('Please try again Later');
        location.replace('sign_up.php');
        </script>";
	}
	

}
}

?>