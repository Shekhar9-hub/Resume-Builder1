<?php
session_start();
$id = $_GET['id'];
include('dbconn.php');
$sql = "select * from personal_details where id = $id";
$result1 = $con->query($sql);
$row = $result1->fetch_array();
$temp = $row['temp_id'];
$sq = "select * from education_details where eid = $id";
$result2 = $con->query($sq);
$row2 = $result2->fetch_array();
?>
<!DOCTYPE html>
<html>
    <head>
        <title>Professional Resume</title>
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
        <link rel="stylesheet" href="css/bootstrap.min.css">
        <link rel="stylesheet" href="css/w3.css">
        <script src="js/bootstrap.min.js"></script>
<style>
       body{
           margin:30px;
           font-family: 'Lucida Sans', 'Lucida Sans Regular', 'Lucida Grande', 'Lucida Sans Unicode', Geneva, Verdana, sans-serif;
       }     
        </style>
    </head>
    <body>
        <h1>Edit Details</h1>
        <h1 class="text-center font-weight-bold"><?php echo $row['name']; ?></h1>
        <form method='post'>
      <table class='table table-borderless table-striped table-hover shadow border border-light'>
          <tr><td colspan='4'>Address<br>
       <textarea name='address' class='form-control' required><?php echo $row['address'];  ?></textarea></td></tr>
       <tr><td colspan="2">Email<br>
     <input type='email' name='email' value="<?php echo $row['email']; ?>" class="form-control" size="30" required></td>
   <td colspan="2">Mobile No.
     <input type='number' name='phone' value="<?php echo $row['phone']; ?>" class="form-control" size="30" required></td></tr>
     <tr><td colspan='4'>Professional summary<br>
       <textarea name='summary' class='form-control' required><?php echo $row2['summary'];  ?></textarea></td></tr>
       <tr><td>Employment History Starting Date<br>
       <input type='text' name='sdate' value="<?php echo $row['sdate']; ?>" class="form-control" size="30" required></td>
       </td>
       <td>Employment History Ending Date<br>
       <input type='text' name='edate' value="<?php echo $row['edate']; ?>" class="form-control" size="30" required></td>
       </td>
       <td>Working as<br>
       <input type='text' name='job' value="<?php echo $row['job']; ?>" class="form-control" size="30" required></td>
       </td>
       <td>Job Description<br>
       <textarea name='desp' class="form-control" size="30" required><?php echo $row['desp']; ?></textarea>
       </td></tr>
       <tr><td>Education Graduation Year<br>
       <input type='text' name='grad' value="<?php echo $row2['grad']; ?>" class="form-control" size="30" required></td>
       </td>
       <td>College Name<br>
       <input type='text' name='cname' value="<?php echo $row2['college']; ?>" class="form-control" size="30" required></td>
       </td>
       <td>Course<br>
       <input type='text' name='course' value="<?php echo $row2['deg']; ?>" class="form-control" size="30" required></td>
       </td>
       <td>Graduation Marks<br>
       <input type='number' name='gmark' value="<?php echo $row2['gmark']; ?>" class="form-control" size="30" required></td>
       
       </td></tr>
       <tr><td colspan='2'>City<br>
       <input type='text' name='city' value="<?php echo $row2['city']; ?>" class="form-control" size="30" required></td>
       
    </td>
    <td colspan='2'>State<br>
    <input type='text' name='state' value="<?php echo $row2['state']; ?>" class="form-control" size="30" required></td>
       
    </td>
    </tr>
    <tr><td>Education School<br>
       <input type='text' name='school' value="<?php echo $row2['school']; ?>" class="form-control" size="30" required></td>
       </td>
       <td>College Name<br>
       <input type='text' name='high' value="<?php echo $row2['high']; ?>" class="form-control" size="30" required></td>
       </td>
       
       <td colspan="2">Marks<br>
       <input type='number' name='marks' value="<?php echo $row2['marks']; ?>" class="form-control" size="30" required></td>
       
       </td></tr>
       <tr><td colspan='2'>City<br>
       <input type='text' name='sc' value="<?php echo $row2['sc']; ?>" class="form-control" size="30" required></td>
       
    </td>
    <td colspan='2'>State<br>
    <input type='text' name='ss' value="<?php echo $row2['sc']; ?>" class="form-control" size="30" required></td>
       
    </td>
    </tr>
    <tr><td colspan="2">Post Graduation<br>
       <input type='text' name='pname' value="<?php echo $row2['pname']; ?>" class="form-control" size="30" required></td>
       </td>
       <td colspan="2">Course Name<br>
       <input type='text' name='pdeg' value="<?php echo $row2['pdeg']; ?>" class="form-control" size="30" required></td>
       </td></tr>
       <tr>
       <td colspan="2">Year<br>
       <input type='text' name='pdate' value="<?php echo $row2['pdate']; ?>" class="form-control" size="30" required></td>
       
       </td>
       <td colspan="2">Marks<br>
       <input type='number' name='pmark' value="<?php echo $row2['pmark']; ?>" class="form-control" size="30" required></td>
       
       </td>
       
       </tr>  
       <tr><td colspan="2">Other Education<br>
       <input type='text' name='oname' value="<?php echo $row2['oname']; ?>" class="form-control" size="30" required></td>
       </td>
       <td colspan="2">Course Name<br>
       <input type='text' name='odeg' value="<?php echo $row2['odeg']; ?>" class="form-control" size="30" required></td>
       </td></tr>
       <tr>
       <td colspan="2">Year<br>
       <input type='text' name='odate' value="<?php echo $row2['odate']; ?>" class="form-control" size="30" required></td>
       
       </td>
       <td colspan="2">Marks<br>
       <input type='number' name='omark' value="<?php echo $row2['omark']; ?>" class="form-control" size="30" required></td>
       
       </td>
       
       </tr>  
       <tr>
       <td colspan="2">Hobby<br>
       <input type='text' name='h1' value="<?php echo $row2['h1']; ?>" class="form-control" size="30" required></td>
      </td>
       <td colspan="2">Hobby<br>
       <input type='text' name='h2' value="<?php echo $row2['h2']; ?>" class="form-control" size="30" required></td>
       </td>
       </tr>  
       <tr>
       <td colspan="2">Skills<br>
       <input type='text' name='skill' value="<?php echo $row2['skill']; ?>" class="form-control" size="30" required></td>
      </td>
       <td colspan="2">Level<br>
       <input type='text' name='level' value="<?php echo $row2['level']; ?>" class="form-control" size="30" required></td>
       </td>
       </tr>  
       <tr>
       <td colspan="2">Skills<br>
       <input type='text' name='skill1' value="<?php echo $row2['skill2']; ?>" class="form-control" size="30" required></td>
      </td>
       <td colspan="2">Level<br>
       <input type='text' name='level1' value="<?php echo $row2['level2']; ?>" class="form-control" size="30" required></td>
       </td>
       </tr>  
       <tr>
       <td colspan="2">Skills<br>
       <input type='text' name='skill2' value="<?php echo $row2['skill3']; ?>" class="form-control" size="30" required></td>
      </td>
       <td colspan="2">Level<br>
       <input type='text' name='level2' value="<?php echo $row2['level3']; ?>" class="form-control" size="30" required></td>
       </td>
       </tr>  
       <tr><td colspan='4' align="right">
       <input type="submit" class="btn btn-primary" value="Update Details" name="submit">
       </td>
       
       

    </table>
    </form>

    </body>
    <?php
      if(isset($_POST['submit']))
      {
        $id = $_GET['id'];
        $a1 = $_POST['address'];
        $a2 = $_POST['email'];
        $a3 = $_POST['phone'];
        $a4 = $_POST['summary'];
        $a5 = $_POST['sdate'];
        $a6 = $_POST['edate'];
        $a7 = $_POST['job'];
        $a8 = $_POST['desp'];
        $a9 = $_POST['grad'];
        $a10 = $_POST['cname'];
        $a11 = $_POST['course'];
        $a12 = $_POST['gmark'];
        $a13 = $_POST['city'];
        $a14 = $_POST['state'];
        $b10 = $_POST['school'];
        $b11 = $_POST['high'];
        $b12 = $_POST['marks'];
        $b13 = $_POST['sc'];
        $b14 = $_POST['ss'];
        
        $a15 = $_POST['pname'];
        $a16 = $_POST['pdeg'];
        $a17 = $_POST['pdate'];
        $a18 = $_POST['pmark'];
        $a19 = $_POST['oname'];
        $a20 = $_POST['odeg'];
        $a22 = $_POST['omark'];
        $a21 = $_POST['odate'];
        $a23 = $_POST['h1'];
        $a24 = $_POST['h2'];
        $a25 = $_POST['skill'];
        $a26 = $_POST['level'];
        $a27 = $_POST['skill1'];
        $a28 = $_POST['level1'];
        $a29 = $_POST['skill2'];
        $a30 = $_POST['level2'];
        $q1 = "update personal_details set address='$a1',email='$a2',phone='$a3',job='$a7',sdate='$a5',edate='$a6',desp='$a8' where id = $id";
        if($con->query($q1))
        {
          $q2 = "update education_details set college='$a10',city='$a13',state='$a14',deg='$a11',grad='$a9',gmark='$a12',school='$b10',
          sc='$b13',ss='$b14',marks='$b12',high='$b11',skill='$a25',level='$a26',skill2='$a27',level2='$a28',skill3='$a29',level3='$a30',
          summary='$a4',pname='$a15',pdeg='$a16',pdate='$a17',pmark='$a18',oname='$a19',odeg='$a20',odate='$a21',omark='$a22',h1='$a23',
          h2='$a24' where eid = $id";
          if($con->query($q2))
          {
            echo "<script>alert('Details are updated');location.replace('welcomeresume.php#resume');</script>";
          //   if($temp == 1)
          //   {
          //   echo "<script>alert('Details are updated');location.replace('professional.php?id=$id&eid=$id');</script>";
          // }
          // else if($temp == 2)
          // {
          //   echo "<script>alert('Details are updated');location.replace('creative.php?id=$id&eid=$id');</script>";
            
          // }
          // else
          // {
          //   echo "<script>alert('Details are updated');location.replace('simple.php?id=$id&eid=$id');</script>";
            
          // }
        
        }


      }
    }


      ?>