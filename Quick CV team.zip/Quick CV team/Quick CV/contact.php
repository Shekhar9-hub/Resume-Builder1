<!DOCTYPE html>
<html lang="en">
<head>
  <title>Online Resume Buider</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
  <link href="https://fonts.googleapis.com/css?family=Montserrat" rel="stylesheet" type="text/css">
  <link href="https://fonts.googleapis.com/css?family=Lato" rel="stylesheet" type="text/css">
  <link rel="stylesheet" href="css/style.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
  
</head>
<body id="myPage" data-spy="scroll" data-target=".navbar" data-offset="60">

<nav class="navbar navbar-default navbar-fixed-top">
  <div class="container">
    <div class="navbar-header">
      <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#myNavbar">
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>                        
      </button>
      <a class="navbar-brand" href="index.php">Quick CV</a>
    </div>
    <div class="collapse navbar-collapse" id="myNavbar">
      <ul class="nav navbar-nav navbar-right">
        <li><a href="index.php">ABOUT</a></li>
        <li><a href="services.php">SERVICES</a></li>
        <li><a href="signin.php">CREATE RESUME</a></li>
        <li><a href="adminlogin.php">ADMIN LOGIN</a></li>
        <li><a href="contact.php">CONTACT</a></li>
      </ul>
    </div>
  </div>
</nav>

  <!-- Container (Contact Section) -->
<div id="contact" class="container-fluid bg-grey">
  <h2 class="text-center" style="padding-top:100px">CONTACT</h2>
  <div class="row">
    <div class="col-sm-5">
      <p>Contact us and we'll get back to you within 24 hours.</p>
      <p><span class="glyphicon glyphicon-map-marker"></span>Punjab</p>
      <p><span class="glyphicon glyphicon-phone"></span> +91-7298027390 </p>
      <p><span class="glyphicon glyphicon-envelope"></span> rishab17mehta.com</p>
    </div>
    <div class="col-sm-7">
      <div class="row">
        <div class="col-sm-6 form-group">
            <form method='post'>
          <input class="form-control" id="name" name="name" placeholder="Name" type="text" required>
        </div>
        <div class="col-sm-6 form-group">
          <input class="form-control" id="email" name="email" placeholder="Email" type="email" required>
        </div>
      </div>
      <textarea class="form-control" id="comments" name="comments" placeholder="Comment" rows="5"></textarea><br>
      <div class="row">
        <div class="col-sm-12 form-group">
          <button class="btn btn-danger pull-right" type="submit" name='send'>Send</button>
</form>
        </div>+
      </div>
    </div>
  </div>
</div>

<!-- Image of location/map -->
<img src="img/bg_1.jpg" style="width:100%;height:400px;object-fit:cover">
</div>


<footer class="container-fluid text-center">
  <a href="#myPage" title="To Top">
    <span class="glyphicon glyphicon-chevron-up"></span>
  </a>
  <p> Developed by Us</p>
</footer>

</body>

<?php
if(isset($_POST['send']))
{
  include('dbconn.php');
    $n = $_POST['name'];
    $a = $_POST['email'];
    $b = $_POST['comments'];
    date_default_timezone_set("Asia/Kolkata");
  $d = date("d/m/Y h:i:s a",time());
    $q = "insert into contact(name,email,comment,dtime) values ('$n','$a','$b','$d')";
    if($con->query($q))
	{
        echo "<script>alert('Query is send successfully');
        location.replace('contact.php');</script>";
	}
	
	
	else
	{
        echo "<script>alert('Query is not send');
        location.replace('contact.php');
        </script>";
	}
	

}


?>